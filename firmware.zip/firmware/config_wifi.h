#ifndef CONFIG_WIFI_H
#define CONFIG_WIFI_H

#define WIFI_SSID     "SUA_REDE"
#define WIFI_PASSWORD "SUA_SENHA"
#define BACKEND_HOST   "192.168.1.100"
#define BACKEND_PORT   3000
#define MACHINE_ID     "COLE_O_UUID_DA_MAQUINA_AQUI"
#define MACHINE_TOKEN  "dev-token-máquina-1"

#endif
